globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/8d756db9d0a8d800.js",
    "static/chunks/fe7fbd176ec0a3a6.js",
    "static/chunks/b55637116a1eeee4.js",
    "static/chunks/cbad4a0108e19489.js",
    "static/chunks/e7c78982398df124.js",
    "static/chunks/turbopack-e98286a8f16976d0.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];