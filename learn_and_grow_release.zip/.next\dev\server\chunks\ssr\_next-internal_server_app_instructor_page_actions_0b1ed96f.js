module.exports = [
"[project]/.next-internal/server/app/instructor/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_instructor_page_actions_0b1ed96f.js.map