globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/node_modules_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_c8babe70._.js",
    "static/chunks/node_modules_next_dist_compiled_react-dom_1e674e59._.js",
    "static/chunks/node_modules_next_dist_compiled_react-server-dom-turbopack_9212ccad._.js",
    "static/chunks/node_modules_next_dist_compiled_next-devtools_index_1dd7fb59.js",
    "static/chunks/node_modules_next_dist_compiled_a0e4c7b4._.js",
    "static/chunks/node_modules_next_dist_client_aaee43fe._.js",
    "static/chunks/node_modules_next_dist_7a8122d0._.js",
    "static/chunks/4e2c9_@swc_helpers_cjs_0c5313ba._.js",
    "static/chunks/_a0ff3932._.js",
    "static/chunks/turbopack-_cf1a2523._.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];